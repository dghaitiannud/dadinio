const plans=[
 {id:'7d',label:'7 jours',price:4.99,perday:.71},
 {id:'15d',label:'15 jours',price:8.99,perday:.60},
 {id:'30d',label:'30 jours',price:14.99,perday:.50,featured:true,tag:'POPULAIRE'},
 {id:'60d',label:'60 jours',price:26.99,perday:.45},
 {id:'90d',label:'90 jours',price:36.99,perday:.41},
 {id:'180d',label:'180 jours',price:64.99,perday:.36,tag:'MEILLEUR PRIX'},
 {id:'365d',label:'365 jours',price:119.99,perday:.33}
];
let selected=plans[2],method='moncash';
const fmt=n=>new Intl.NumberFormat('fr-HT',{style:'currency',currency:'USD'}).format(n);
const plansEl=document.querySelector('#plans');
function renderPlans(){plansEl.innerHTML=plans.map(p=>`<button class="plan ${p.featured?'featured':''} ${selected.id===p.id?'selected':''}" data-plan="${p.id}" aria-pressed="${selected.id===p.id}"><span class="duration">${p.label}</span>${p.tag?`<span class="tag">${p.tag}</span>`:''}<div class="price">${fmt(p.price)}</div><div class="perday">${fmt(p.perday)} / jour</div><span class="selectline">✓</span></button>`).join('');plansEl.querySelectorAll('.plan').forEach(btn=>btn.addEventListener('click',()=>{selected=plans.find(p=>p.id===btn.dataset.plan);renderPlans();renderSummary()}));}
function renderSummary(){document.querySelector('#orderSummary').innerHTML=`<div class="order-row"><span class="order-plan">Nexora Plus · ${selected.label}</span><strong>${fmt(selected.price)}</strong></div><div class="order-row muted"><span>Accès</span><span>${selected.label}</span></div><div class="order-row muted"><span>Frais supplémentaires</span><span>—</span></div><div class="order-row total"><span>Total</span><span>${fmt(selected.price)}</span></div>`;}
const paymentMethods=[{id:'moncash',name:'MonCash',detail:'Paiement mobile en gourdes',brand:'moncash'},{id:'natcash',name:'NatCash',detail:'Paiement mobile en gourdes',brand:'natcash'}];
function renderMethods(){document.querySelector('#methods').innerHTML=paymentMethods.map(m=>`<div class="method ${method===m.id?'selected':''}" data-method="${m.id}" role="radio" aria-checked="${method===m.id}" tabindex="0"><div class="method-logo"><span class="${m.brand}">${m.id==='moncash'?'MON\nCash':'nat\ncash'}</span></div><div><div class="method-name">${m.name}</div><div class="method-detail">${m.detail}</div></div><span class="radio"></span></div>`).join('');document.querySelectorAll('.method').forEach(el=>{const select=()=>{method=el.dataset.method;renderMethods()};el.addEventListener('click',select);el.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();select()}})});}
function toast(msg){const el=document.querySelector('#toast');el.textContent=msg;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600)}
document.querySelector('#payBtn').addEventListener('click',()=>toast(`Démo : paiement ${method==='moncash'?'MonCash':'NatCash'} · ${fmt(selected.price)} · ${selected.label}`));document.querySelector('#manualBtn').addEventListener('click',()=>toast('Démo : ouverture du parcours de paiement manuel.'));
renderPlans();renderSummary();renderMethods();

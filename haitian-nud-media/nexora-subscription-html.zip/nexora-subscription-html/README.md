# Nexora — Subscription UI & Checkout (HTML/CSS/JS)

A standalone responsive pricing + checkout demo in vanilla HTML, CSS and JavaScript.

## Run
Open `index.html` in a browser. No build step required.

## Included
- 7 subscription durations, selectable cards
- Order summary updates instantly
- Mobile-money method selection (MonCash / NatCash)
- Primary automatic-payment CTA and secondary manual-payment CTA
- Responsive desktop/mobile layouts
- Demo toast callbacks (replace with real checkout calls)

## Logos
The payment method marks are CSS-rendered approximations for this prototype, not official logo image files. Network access was unavailable in the build environment, so official logo assets could not be downloaded/verified. Replace `method-logo` contents with verified official MonCash/NatCash assets before production use.

import React, { useMemo, useState } from 'react';
import { plansCopy, PlansLocale } from '../i18n/plans';
import '../styles/plans.css';


export type SubscriptionPlan = { id: string; days: number; price: number; currency?: string };
type Props = {
  locale?: PlansLocale;
  currentPlan?: 'free' | 'premium';
  plans?: SubscriptionPlan[];
  onAutomaticCheckout?: (planId: string) => void;
  onManualPayment?: (planId: string) => void;
};
const defaults: SubscriptionPlan[] = [
  { id: 'p7', days: 7, price: 2.99 }, { id: 'p30', days: 30, price: 7.99 },
  { id: 'p90', days: 90, price: 19.99 }, { id: 'p180', days: 180, price: 34.99 },
  { id: 'p365', days: 365, price: 59.99 }, { id: 'p730', days: 730, price: 99.99 },
  { id: 'p1095', days: 1095, price: 139.99 },
];
const money = (amount: number, currency: string, locale: string) => new Intl.NumberFormat(locale, { style: 'currency', currency }).format(amount);

export default function Plans({ locale = 'en', currentPlan = 'free', plans = defaults, onAutomaticCheckout, onManualPayment }: Props) {
  const t = plansCopy[locale];
  const [selected, setSelected] = useState(plans[1]?.id ?? plans[0]?.id);
  const plan = useMemo(() => plans.find(p => p.id === selected) ?? plans[0], [plans, selected]);
  const localeTag = ({ en: 'en-US', fr: 'fr-FR', ht: 'fr-HT', es: 'es-ES' } as const)[locale];
  if (!plan) return null;
  return <main className="nex-plans">
    <div className="nex-shell">
      <header className="nex-header">
        <div className="nex-eyebrow">{t.eyebrow}</div>
        <h1>{t.title}</h1>
        <p>{t.subtitle}</p>
        {currentPlan === 'premium' && <span className="nex-current">{t.current}: {t.premium}</span>}
      </header>
      <section className="nex-grid" aria-label="Subscription options">
        {plans.map((item, index) => {
          const active = item.id === selected;
          const featured = index === 1;
          return <button key={item.id} type="button" className={`nex-plan ${active ? 'is-selected' : ''}`} aria-pressed={active} onClick={() => setSelected(item.id)}>
            {featured && <span className="nex-tag">{t.popular}</span>}
            <span className="nex-plan-days">{item.days} <small>{t.days}</small></span>
            <span className="nex-price">{money(item.price, item.currency ?? 'USD', localeTag)}</span>
            <span className="nex-rate">{money(item.price / item.days, item.currency ?? 'USD', localeTag)} {t.perDay}</span>
            <span className={`nex-radio ${active ? 'checked' : ''}`} aria-hidden="true">{active ? '✓' : ''}</span>
          </button>;
        })}
      </section>
      <section className="nex-checkout" aria-live="polite">
        <div className="nex-summary"><span>{t.total}</span><strong>{money(plan.price, plan.currency ?? 'USD', localeTag)}</strong><small>{plan.days} {t.days}</small></div>
        <button className="nex-primary" onClick={() => onAutomaticCheckout?.(plan.id)}>{t.automatic}<span aria-hidden="true">↗</span></button>
        <button className="nex-secondary" onClick={() => onManualPayment?.(plan.id)}>{t.manual}</button>
        <p className="nex-note">{t.paymentNote}</p>
        <details className="nex-manual-help"><summary>{t.manual}</summary><p>{t.manualHint}</p></details>
      </section>
    </div>
  </main>;
}

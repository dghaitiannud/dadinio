export type PlansLocale = 'en' | 'fr' | 'ht' | 'es';

export const plansCopy = {
  en: {
    eyebrow: 'MEMBERSHIP', title: 'Make more room for what matters.', subtitle: 'Choose the access period that works for you. You can renew or upgrade anytime.',
    monthly: 'Monthly access', days: 'days', popular: 'Most popular', selected: 'Selected', choose: 'Choose plan',
    automatic: 'Continue to secure checkout', manual: 'Other payment option', manualHint: 'Prefer to pay manually? Continue with the alternative payment flow.',
    perDay: 'per day', total: 'Total', current: 'Current plan', premium: 'Premium access', free: 'Free',
    paymentNote: 'Payment options are shown at checkout. Your plan is activated after payment confirmation.',
  },
  fr: {
    eyebrow: 'ABONNEMENT', title: 'Plus de place pour ce qui compte.', subtitle: 'Choisissez la durée qui vous convient. Vous pouvez renouveler ou changer de formule à tout moment.',
    monthly: 'Accès', days: 'jours', popular: 'Le plus choisi', selected: 'Sélectionné', choose: 'Choisir cette formule',
    automatic: 'Continuer vers le paiement sécurisé', manual: 'Autre option de paiement', manualHint: 'Vous préférez payer manuellement ? Utilisez l’autre parcours de paiement.',
    perDay: 'par jour', total: 'Total', current: 'Formule actuelle', premium: 'Accès Premium', free: 'Gratuit',
    paymentNote: 'Les options de paiement sont présentées à l’étape suivante. Votre formule est activée après confirmation du paiement.',
  },
  ht: {
    eyebrow: 'ABÒNMAN', title: 'Plis espas pou sa ki enpòtan.', subtitle: 'Chwazi dire aksè ki pi bon pou ou. Ou ka renouvle oswa chanje plan nenpòt lè.',
    monthly: 'Aksè', days: 'jou', popular: 'Plis moun chwazi l', selected: 'Chwazi', choose: 'Chwazi plan sa a',
    automatic: 'Kontinye nan peman an sekirite', manual: 'Lòt opsyon peman', manualHint: 'Ou prefere peye manyèlman? Kontinye ak lòt metòd peman an.',
    perDay: 'pa jou', total: 'Total', current: 'Plan aktyèl', premium: 'Aksè Premium', free: 'Gratis',
    paymentNote: 'Ou pral wè opsyon peman yo nan pwochen etap la. Plan ou aktive apre peman an konfime.',
  },
  es: {
    eyebrow: 'SUSCRIPCIÓN', title: 'Más espacio para lo que importa.', subtitle: 'Elige el período de acceso que mejor te convenga. Puedes renovar o cambiar de plan cuando quieras.',
    monthly: 'Acceso', days: 'días', popular: 'Más elegido', selected: 'Seleccionado', choose: 'Elegir plan',
    automatic: 'Continuar al pago seguro', manual: 'Otra opción de pago', manualHint: '¿Prefieres pagar manualmente? Continúa con el método alternativo.',
    perDay: 'por día', total: 'Total', current: 'Plan actual', premium: 'Acceso Premium', free: 'Gratis',
    paymentNote: 'Las opciones de pago aparecerán en el siguiente paso. El plan se activa tras confirmar el pago.',
  },
} as const;

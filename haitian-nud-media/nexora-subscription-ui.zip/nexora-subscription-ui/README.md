# Nexora — Subscription UI starter

Neutral demo subscription page for a fictional productivity platform. Built as a standalone React + TypeScript UI reference.

## Included
- 7 selectable subscription durations
- Automatic checkout as the primary action
- Manual payment as a secondary alternative
- Responsive layout and accessible selection controls
- Translations: English, French, Haitian Creole, Spanish
- No payment provider branding in user-facing UI

## Integration
Copy `src/pages/Plans.tsx`, `src/styles/plans.css`, and `src/i18n/plans.ts` into your frontend.

The component accepts:
- `currentPlan?: 'free' | 'premium'`
- `onAutomaticCheckout(planId: string): void`
- `onManualPayment(planId: string): void`
- `locale?: 'en' | 'fr' | 'ht' | 'es'`

The callbacks are intentionally placeholders for your existing checkout/payment logic. No backend or real payment flow is included.
